<?php

/**
 * WS-Federation SP configuration for SimpleSAMLphp.
 *
 * Required fields:
 *  - host
 */

$metadata['__DYNAMIC:1__'] = [
    'host' => '__DEFAULT__',
];
